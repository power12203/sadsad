import React from "react";

const WritePage = () => {
  return <div>WritePage</div>;
};

export default WritePage;
